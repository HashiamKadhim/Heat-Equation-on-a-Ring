The diffring implements discretization and the walkring implements walkers and hence is a Monte Carlo simulation which also includes visualization. 
